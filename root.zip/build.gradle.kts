pluginManagement {
    repositories {
        gradlePluginPortal()  // For plugin management
        google()              // Google's repository for Android plugins
        mavenCentral()        // Maven Central repository
    }
}

dependencyResolutionManagement {
    repositories {
        google()              // Google's repository for dependencies
        mavenCentral()        // Maven Central repository
    }
}

dependencyResolutionManagement {
    versionCatalogs {
        create("libs") {
            version("retrofit", "2.9.0")
            library("retrofit", "com.squareup.retrofit2:retrofit")
        }
    }
}

rootProject.name = "enpy.root"

// You can optionally add version catalogs here to manage dependency versions centrally (optional)