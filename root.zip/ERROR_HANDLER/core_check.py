import os

import time

import sys


# Path to check for the core.py file

file_path = "/root.zip/core1/core/core.py"

log_path = "/root.zip/log/error_log.txt"


# Monitor for core.py existence

def monitor_core_file():

    while True:

        if os.path.exists(file_path):

            print("core.py found. Monitoring...")

        else:

            print("ERR: core.py not found. Initiating shutdown procedure...")


            # Log the error message

            with open(log_path, "a") as log_file:

                log_file.write("ERR core.py not found. Please flash your phone via USB debugging and remove the rooting file to prevent potential damage to this device. in about 1 minute we will initialize the root remover folder that will make it safe to remove the rooting file. please wait...\n")


            # Shut down or reboot to recovery

            os.system("reboot recovery")  # This command should work with root access

            

            # Exit the script after logging error

            sys.exit()

        

        time.sleep(10)  # Check every 10 seconds


# Run the monitor

monitor_core_file()

