import os
import shutil
from pathlib import Path
from zipfile import ZipFile, BadZipFile
import subprocess

ZIP_FILES_DIRECTORY = Path('/root.zip/media/Zips')

CACHE_DIRECTORY = Path('/root.zip/main/cache/cache1.txt')

LOG_FILE = Path('/root.zip/log/log7.txt') # Separate log file path


def extract_and_copy_files(zip_path, cache_directory):
        with ZipFile(zip_path, 'r') as zip_ref:
            zip_contents = zip_ref.namelist()
            print(f'Processing {zip_path}:')

            for file_name in zip_contents:
                if file_name.endswith('.py'):  # If it's a Python script, extract it and execute
                    print(f' - Found Python script: {file_name}')
                    extracted_path = cache_directory / file_name
                    zip_ref.extract(file_name, cache_directory)  # Extract the Python file
                    execute_script(extracted_path)  # Execute the Python file

    except BadZipFile:
        print(f'Error: {zip_path} is not a valid ZIP file.')

def execute_script(script_path):
    """Execute a Python script and log the result."""
    try:
        print(f'Executing {script_path}...')
        result = subprocess.run(['python', str(script_path)], capture_output=True, text=True)
        output = result.stdout if result.returncode == 0 else result.stderr
        success = result.returncode == 0

        # Log the output and the success status
        log_to_file(script_path, output, success)
    except Exception as e:
        log_to_file(script_path, str(e), False)

def log_to_file(script_path, output, success):
    """Log the result of executing a script."""
    with open(LOG_FILE, 'a') as log:
        log.write(f'Output for {script_path}:\n{output}\n')
        log.write(f'Success: {success}\n\n')
    print(f' - Log written for {script_path}. Success: {success}')

def main():
    # Create the cache directory if it doesn't exist
    cache_directory = CACHE_DIRECTORY
    cache_directory.mkdir(parents=True, exist_ok=True)

    # Clear or create log file
    log_file = LOG_FILE
    log_file.parent.mkdir(parents=True, exist_ok=True)  # Ensure the log directory exists
    with open(log_file, 'w') as log:
        log.write('Execution Log:\n\n')  # Initialize the log file

    # Iterate over all ZIP files in the specified directory
    for zip_file_path in ZIP_FILES_DIRECTORY.glob('*.zip'):
        extract_and_copy_files(zip_file_path, cache_directory)

if __name__ == '__main__':
    main()
