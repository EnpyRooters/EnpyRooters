from enpy import RootProcessManager, SanitizedRootProcessManager

# Initialize the RootProcessManager
root_manager = RootProcessManager()

# Initialize the SanitizedRootProcessManager
sanitized_manager = SanitizedRootProcessManager()

# Using the root process manager to check root and execute commands
if root_manager.check_root():
    print(root_manager.execute_root_command("ls /root"))
else:
    print("You need root privileges to run this command.")

# Using the sanitized manager to execute a safe command
command = "ls -l /home"
if sanitized_manager.is_safe_command(command):
    print(sanitized_manager.execute_sanitized_command(command))
else:
    print("The command is not safe to execute.")