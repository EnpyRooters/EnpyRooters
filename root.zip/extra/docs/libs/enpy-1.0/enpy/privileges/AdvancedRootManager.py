# enpy/modules/AdvancedRootManager.py

from enpy.modules.OSRootManager import OSRootManager

class AdvancedRootManager(OSRootManager):
    def __init__(self):
        super().__init__()
        print("AdvancedRootManager initialized")

    def restart_service(self, service_name):
        """Restart a system service (Linux example)."""
        if not self.is_root():
            return "Root privileges are required to restart a service."
        return self.execute_command(f"systemctl restart {service_name}")

    def change_owner(self, path, owner):
        """Change ownership of a file/directory."""
        if not self.is_root():
            return "Root privileges are required to change ownership."
        return self.execute_command(f"chown {owner} {path}")