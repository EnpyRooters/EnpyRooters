# enpy/privileges/sanitized.py

import subprocess
import shlex

class SanitizedRootProcessManager:
    def __init__(self):
        pass

    def execute_sanitized_command(self, command):
        """Execute a sanitized version of the command (to avoid security risks)"""
        try:
            # Use shlex.split to safely parse the command and its arguments
            sanitized_command = shlex.split(command)
            result = subprocess.run(sanitized_command, check=True, text=True, capture_output=True)
            return result.stdout
        except subprocess.CalledProcessError as e:
            return f"Error: {e.stderr}"

    def is_safe_command(self, command):
        """Check if the command is considered safe"""
        # Implement basic sanitization checks (e.g., block dangerous commands like rm, shutdown)
        dangerous_commands = ['rm', 'shutdown', 'reboot']
        for cmd in dangerous_commands:
            if cmd in command:
                return False
        return True