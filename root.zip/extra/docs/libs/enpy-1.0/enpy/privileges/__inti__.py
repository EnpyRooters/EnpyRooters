from enpy import RootProcessManager, SanitizedRootProcessManager

# Use the RootProcessManager
root_manager = RootProcessManager()

# Use the SanitizedRootProcessManager
sanitized_manager = SanitizedRootProcessManager()