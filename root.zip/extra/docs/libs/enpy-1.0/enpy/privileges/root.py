# enpy/privileges/root.py

import subprocess
from enpy.modules.OSRootManager import OSRootManager
from enpy.modules.AdvancedRootManager import AdvancedRootManager

class RootProcessManager:
    def __init__(self):
        self.os_manager = OSRootManager()
        self.adv_manager = AdvancedRootManager()

    def execute_root_command(self, command):
        """Execute a command as root (use with caution)"""
        try:
            result = subprocess.run(['sudo', command], check=True, text=True, capture_output=True)
            return result.stdout
        except subprocess.CalledProcessError as e:
            return f"Error: {e.stderr}"

    def check_root(self):
        """Check if the current user has root privileges"""
        result = subprocess.run(['id', '-u'], capture_output=True, text=True)
        return result.stdout.strip() == '0'

    def use_os_manager(self):
        """Example method to demonstrate integration with OSRootManager"""
        if self.os_manager.is_root():
            print("OS Manager confirms root privileges.")
        else:
            print("OS Manager denies root privileges.")

    def use_adv_manager(self):
        """Example method to demonstrate integration with AdvancedRootManager"""
        print(self.adv_manager.restart_service("networking"))