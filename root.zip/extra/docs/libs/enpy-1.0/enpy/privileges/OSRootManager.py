# enpy/modules/OSRootManager.py

import os

class OSRootManager:
    def __init__(self):
        print("OSRootManager initialized")

    def is_root(self):
        """Check if the script has root privileges."""
        return os.geteuid() == 0  # Works on Linux-based systems

    def execute_command(self, command):
        """Execute a system command."""
        try:
            result = os.system(command)
            return result
        except Exception as e:
            return f"Error executing command: {e}"