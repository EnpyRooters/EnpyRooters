#!/usr/bin/env python3

import argparse
import glob
import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path
from zipfile import ZipFile

# Paths
ROOT_DIR = Path("/root.zip/safe/safer/safest/more")  # Safe location for binaries and scripts
BOOT_SCRIPT = Path("/root.zip/full/scripts/boot.py")  # Boot script path
SUPERUSER_BINARY = Path("/root.zip/Core1/SU_binary/su_bin.ndk")  # Path to your superuser binary
ROOT_ZIP_PATH = Path("/root.zip/")  # Path where zip files are stored
ELF_WORK_DIR = Path("/root.zip/ELF_work/")  # Directory to clean ELF files from
CPP_SOURCE_DIR = Path("/root.zip/build/cpp_sources/")  # Directory to handle .cpp source files

# Helper Functions
def log(message, level="INFO"):
    print(f"[{level}] {message}")

def manage_zip_files():
    """Manages the zip files in /root.zip/."""
    # Check for all .zip files in /root.zip
    zip_files = list(ROOT_ZIP_PATH.glob("*.zip"))
    if not zip_files:
        log("No zip files found in /root.zip/ directory.")
        return

    log(f"Found {len(zip_files)} zip file(s) in /root.zip/")
    
    # Extract zip files
    for zip_file in zip_files:
        extract_to = ROOT_ZIP_PATH / zip_file.stem  # Extract to a folder named after the zip file
        if not extract_to.exists():
            extract_to.mkdir(parents=True, exist_ok=True)
        
        with ZipFile(zip_file, 'r') as zip_ref:
            log(f"Extracting {zip_file} to {extract_to}")
            zip_ref.extractall(extract_to)
            log(f"Extraction complete for {zip_file}.")
        
        # Optionally, delete the zip file after extraction (if you want)
        zip_file.unlink()
        log(f"Deleted zip file {zip_file}")

def clean_elf_files():
pass

def build_cpp_source_files():
    """Generate .cpp source files or perform build actions on the .cpp sources."""
    if not CPP_SOURCE_DIR.exists():
        log(f"No CPP source directory found at {CPP_SOURCE_DIR}.", level="ERROR")
        return
    
    log(f"Building .cpp source files in {CPP_SOURCE_DIR}...")
    
    # Check for all .cpp files in the source directory
    cpp_files = list(CPP_SOURCE_DIR.glob("*.cpp"))
    if not cpp_files:
        log("No .cpp files found in the source directory.", level="WARNING")
        return
    
    # Perform compilation or whatever build process is needed
    for cpp_file in cpp_files:
        # Here we can call a compiler like g++ to compile the .cpp files
        log(f"Building {cpp_file}...")
        build_command = f"g++ -o {cpp_file.stem}.out {cpp_file}"
        
        try:
            subprocess.run(build_command, shell=True, check=True)
            log(f"Compiled {cpp_file} successfully.")
        except subprocess.CalledProcessError:
            log(f"Failed to compile {cpp_file}.", level="ERROR")

def setup_boot_script():
    """Creates a boot script that will run after reboot."""
    script_content = f"""#!/system/bin/sh
# Boot Script to Start Rooting
{ROOT_DIR}/su --install
"""
    with BOOT_SCRIPT.open("w") as script:
        script.write(script_content)
    BOOT_SCRIPT.chmod(0o755)
    log("Boot script created and made executable.")

def copy_files():
    """Copies necessary files to the persistent location."""
    ROOT_DIR.mkdir(parents=True, exist_ok=True)
    target_su = ROOT_DIR / SUPERUSER_BINARY.name
    shutil.copyfile(SUPERUSER_BINARY, target_su)
    target_su.chmod(stat.S_IXUSR)  # Make executable
    log(f"Copied {SUPERUSER_BINARY} to {target_su}")

def setup_init_rc():
    """Adds the boot script to rc.local or equivalent startup file."""
    init_rc_path = Path("/system/etc/init.d/99rooting")  # Common init.d location
    script_content = f"""#!/system/bin/sh
{BOOT_SCRIPT}
"""
    init_rc_path.write_text(script_content)
    init_rc_path.chmod(0o755)
    log(f"Added boot script to {init_rc_path}.")

def main():
    # Manage zip files in the /root.zip/ directory if the argument is set
    if args.manage_zips:
        manage_zip_files()
    
    # Clean ELF files if the argument is set
    if args.clean_elf:
        clean_elf_files()
    
    # Build .cpp files if the argument is set
    if args.build_cpp:
        build_cpp_source_files()

    # Copy the necessary files and create the boot script
    copy_files()
    setup_boot_script()
    setup_init_rc()

    log("Setup complete. Reboot your phone to apply changes.")

def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Setup rooting process.")

    # Argument to control zip file management
    parser.add_argument(
        "--manage-zips", 
        action="store_true", 
        help="Manage and extract zip files in the /root.zip/ directory."
    )
    
    # Argument to control ELF file cleaning
    parser.add_argument(
        "--clean-elf", 
        action="store_true", 
        help="Clean ELF files in /root.zip/ELF_work/ directory."
    )
    
    # Argument to control building .cpp source files
    parser.add_argument(
        "--build-cpp", 
        action="store_true", 
        help="Build .cpp source files in /root.zip/build/cpp_sources/ directory."
    )
    
    # Argument for verbose logging
    parser.add_argument(
        "-v", "--verbose", 
        action="store_true", 
        help="Enable verbose logging."
    )

    return parser.parse_args()

if __name__ == "__main__":
    args = parse_args()
    main()