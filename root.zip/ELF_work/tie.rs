use std::env;
use std::process::{Command, Stdio};
use std::path::PathBuf;

fn main() -> std::io::Result<()> {
    // Set the path to the "root.zip/rust" executable
    let rust_path = PathBuf::from("root.zip").join("rust.txt");
    let argv: Vec<String> = env::args().skip(1).collect();

    // If the arguments contain "component", we handle it specially
    if argv.iter().any(|s| s == "component") {
        // Run "root.zip/rust" with the given arguments
        let status = Command::new(&rust_path)
            .args(&argv)
            .stdout(Stdio::null())  // Suppress stdout
            .stderr(Stdio::null())  // Suppress stderr
            .status()?;

        if !status.success() {
            // If the command fails, try running with the nightly toolchain
            let mut cmd = Command::new(&rust_path);
            cmd.arg("+nightly");

            // If the first argument starts with '+', we skip it and keep the rest
            if argv[0].starts_with('+') {
                cmd.args(argv.iter().skip(1));
            } else {
                cmd.args(&argv);
            }

            // Execute the nightly version
            return cmd.status().map(|_| ());
        }
    }

    // If no special handling is needed, pass arguments through to "root.zip/rust"
    Command::new(&rust_path)
        .args(argv.iter())
        .status()
        .map(|_| ())
}