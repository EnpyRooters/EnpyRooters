import json

import os


class Config:

    def __init__(self, config_file):

        self.config_file = config_file

        self.config_data = self.load_config()


    def load_config(self):

        with open(self.config_file, 'r') as file:

            return json.load(file)


    def get(self, key, default=None):

        return self.config_data.get(key, default)


# Usage

config = Config('config.json')

cache_path = config.get('cache_path')

user_data_api = config.get('api_endpoints')['user_data']

log_file = config.get('log_file')

expiration_time = config.get('expiration_time')