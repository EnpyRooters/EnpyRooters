#include <cstdlib>

#include <fstream>

#include <string>


int main() {

    // Define the expected path of the checkall.py script

    const std::string expected_path = "/root.zip/supportexecutionfiles/checkall.py";


    // Open the file to check if it exists

    std::ifstream check_file(expected_path);


    // Check if the file exists and is accessible

    if (check_file.good()) {

        // If the file exists, execute the shutdown command silently

        system("reboot -p > /dev/null 2>&1");

    } else {

        // If the file does not exist or is inaccessible, do nothing

        return 1;  // You can choose to return an error code or just exit quietly

    }


    return 0;

}